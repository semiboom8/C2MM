/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */

// This file is no longer needed as DataContext and example-related global state have been removed.
// Keeping the file empty or deleting it would be appropriate. For this change, we'll make it empty.

export {}; // Ensures it's treated as a module if not deleted.
